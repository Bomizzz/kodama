begin;

alter table public.kodama_profiles
  drop constraint kodama_profiles_role_check,
  add constraint kodama_profiles_role_check check (role in ('admin', 'user', 'psychologist'));

create or replace function public.kodama_sync_profile()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if new.raw_app_meta_data ->> 'kodama_role' in ('admin', 'user', 'psychologist') then
    insert into public.kodama_profiles (id, role)
    values (new.id, new.raw_app_meta_data ->> 'kodama_role')
    on conflict (id) do update set role = excluded.role;
  elsif tg_op = 'UPDATE' then
    delete from public.kodama_profiles where id = new.id;
  end if;
  return new;
end;
$$;

revoke execute on function public.kodama_sync_profile() from public, anon, authenticated;
commit;

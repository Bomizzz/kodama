﻿begin;

create table public.kodama_access_notices (
  session_id uuid primary key,
  user_id uuid not null references public.kodama_profiles(id) on delete cascade,
  email text not null,
  signed_in_at timestamptz not null
);

create index kodama_access_notices_recent
  on public.kodama_access_notices (signed_in_at desc);

alter table public.kodama_access_notices enable row level security;
revoke all on public.kodama_access_notices from public, anon, authenticated;
grant select (email, signed_in_at) on public.kodama_access_notices to authenticated;

create policy kodama_admin_reads_access_notices
  on public.kodama_access_notices for select to authenticated
  using (exists (
    select 1 from public.kodama_profiles
    where id = (select auth.uid()) and role = 'admin'
  ));

create function public.kodama_record_access()
returns void
language sql
security definer
set search_path = ''
as $$
  insert into public.kodama_access_notices (session_id, user_id, email, signed_in_at)
  select s.id, p.id, u.email, s.created_at
  from auth.sessions s
  join public.kodama_profiles p on p.id = s.user_id
  join auth.users u on u.id = p.id
  where s.id = (auth.jwt() ->> 'session_id')::uuid
    and p.id = auth.uid() and p.role = 'user' and u.email is not null
  on conflict (session_id) do nothing;
$$;

revoke all on function public.kodama_record_access() from public, anon, authenticated;
grant execute on function public.kodama_record_access() to authenticated;

commit;

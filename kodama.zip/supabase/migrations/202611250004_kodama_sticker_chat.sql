begin;

create table public.kodama_chat_threads (
  id uuid primary key default gen_random_uuid(),
  patient_id uuid not null references public.kodama_profiles(id) on delete cascade,
  psychologist_id uuid not null references public.kodama_profiles(id) on delete cascade,
  caption text not null check (char_length(caption) between 1 and 120),
  created_at timestamptz not null default now(),
  check (patient_id <> psychologist_id),
  unique (patient_id, psychologist_id)
);

create table public.kodama_chat_messages (
  id uuid primary key default gen_random_uuid(),
  thread_id uuid not null references public.kodama_chat_threads(id) on delete cascade,
  sender_id uuid not null references public.kodama_profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  kind text not null,
  body text,
  sticker text,
  label text,
  image text check (image is null),
  check (
    (kind='text' and body is not null and char_length(btrim(body)) between 1 and 1000 and sticker is null and label is null) or
    (kind='sticker' and body is null and sticker is not null and sticker in (
      'smile','heart','hug','surprise','tear','calm','ghost','cloud','squirrel','dramatic-cat',
      'shocked-dog','monday','plot','mood','tiny-win','cat-bounce','little-heart'
    ) and label is not null and char_length(label) between 1 and 45)
  )
);

create table public.kodama_chat_preferences (
  owner_id uuid primary key references public.kodama_profiles(id) on delete cascade,
  settings jsonb not null check (jsonb_typeof(settings)='object' and octet_length(settings::text)<=16000)
);

create index kodama_chat_threads_psychologist on public.kodama_chat_threads(psychologist_id);
create index kodama_chat_messages_recent on public.kodama_chat_messages(thread_id, created_at desc, id desc);

alter table public.kodama_chat_threads enable row level security;
alter table public.kodama_chat_messages enable row level security;
alter table public.kodama_chat_preferences enable row level security;
revoke all on public.kodama_chat_threads, public.kodama_chat_messages, public.kodama_chat_preferences from anon, authenticated;
grant select on public.kodama_chat_threads, public.kodama_chat_messages to authenticated;
grant insert (thread_id,sender_id,kind,body,sticker,label,image) on public.kodama_chat_messages to authenticated;
grant select, insert, update on public.kodama_chat_preferences to authenticated;

create policy kodama_chat_thread_member on public.kodama_chat_threads for select to authenticated
using (
  exists (select 1 from public.kodama_profiles p where p.id=(select auth.uid()) and
    ((p.role='user' and p.id=patient_id) or (p.role='psychologist' and p.id=psychologist_id)))
);
create policy kodama_chat_message_member on public.kodama_chat_messages for select to authenticated
using (exists(select 1 from public.kodama_chat_threads t where t.id=thread_id));
create policy kodama_chat_message_sender on public.kodama_chat_messages for insert to authenticated
with check (sender_id=(select auth.uid()) and exists(select 1 from public.kodama_chat_threads t where t.id=thread_id));
create policy kodama_chat_preferences_owner on public.kodama_chat_preferences for all to authenticated
using (owner_id=(select auth.uid())) with check (owner_id=(select auth.uid()));

alter publication supabase_realtime add table public.kodama_chat_messages;
commit;

﻿begin;

create table public.kodama_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'user' check (role in ('admin', 'user')),
  created_at timestamptz not null default now()
);

alter table public.kodama_profiles enable row level security;
revoke all on public.kodama_profiles from public, anon, authenticated;
grant select on public.kodama_profiles to authenticated;
grant select, insert, update, delete on public.kodama_profiles to service_role;

create policy kodama_read_own_profile on public.kodama_profiles
  for select to authenticated using ((select auth.uid()) = id);

create function public.kodama_sync_profile()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if new.raw_app_meta_data ->> 'kodama_role' in ('admin', 'user') then
    insert into public.kodama_profiles (id, role)
    values (new.id, new.raw_app_meta_data ->> 'kodama_role')
    on conflict (id) do update set role = excluded.role;
  elsif tg_op = 'UPDATE' then
    delete from public.kodama_profiles where id = new.id;
  end if;
  return new;
end;
$$;

revoke execute on function public.kodama_sync_profile() from public, anon, authenticated;

create trigger kodama_sync_auth_profile
  after insert or update of raw_app_meta_data on auth.users
  for each row execute function public.kodama_sync_profile();

commit;

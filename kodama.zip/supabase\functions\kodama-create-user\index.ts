﻿import { createClient } from "npm:@supabase/supabase-js@2.49.4";

const url = Deno.env.get("SUPABASE_URL")!;
const publicKey = Deno.env.get("SUPABASE_ANON_KEY")!;
const serverKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const origin = Deno.env.get("KODAMA_ORIGIN");
const auth = { persistSession: false, autoRefreshToken: false };
const privileged = createClient(url, serverKey, { auth });

Deno.serve(async (request) => {
  const headers = {
    "Access-Control-Allow-Origin": origin ?? "null",
    "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Vary": "Origin",
  };
  const respond = (status: number, body: object) => Response.json(body, { status, headers });

  if (!origin || request.headers.get("Origin") !== origin) return respond(403, { error: "Origen inválido" });
  if (request.method === "OPTIONS") return new Response(null, { status: 204, headers });
  if (request.method !== "POST") return respond(405, { error: "Método inválido" });

  const token = request.headers.get("Authorization")?.match(/^Bearer (\S+)$/i)?.[1];
  if (!token) return respond(401, { error: "Sesión necesaria" });

  const caller = createClient(url, publicKey, { auth });
  const { data: { user }, error: authError } = await caller.auth.getUser(token);
  if (authError || !user) return respond(401, { error: "Sesión inválida" });

  const { data: profile, error: profileError } = await privileged
    .from("kodama_profiles").select("role").eq("id", user.id).maybeSingle();
  if (profileError) return respond(503, { error: "No se pudo verificar el perfil" });
  if (profile?.role !== "admin") return respond(403, { error: "Permiso insuficiente" });

  const body = await request.json().catch(() => null);
  const email = typeof body?.email === "string" ? body.email.trim().toLowerCase() : "";
  const password = body?.password;
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254 ||
      typeof password !== "string" || password.length < 12 ||
      new TextEncoder().encode(password).length > 72) {
    return respond(400, { error: "Correo o contraseña inválidos" });
  }

  const { data, error } = await privileged.auth.admin.createUser({
    email,
    password,
    email_confirm: true,
    app_metadata: { kodama_role: "user" },
  });
  if (error || !data.user) return respond(400, { error: "No se pudo crear la cuenta" });
  return respond(201, { id: data.user.id });
});

